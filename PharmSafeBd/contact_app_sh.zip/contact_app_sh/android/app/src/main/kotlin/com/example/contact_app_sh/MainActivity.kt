package com.example.contact_app_sh

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
