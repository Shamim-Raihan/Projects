import 'package:contact_app_sh/models/contact_model.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DBHelper{
  static const String _cereateTableContact = '''
  create table $tableContact(
  $tableContactColId integer primary key autoincrement,
  $tableContactColName text,
  $tableContactColNumber text,
  $tableContactColEmail text,
  $tableContactColAddress text,
  $tableContactColDateOfBirth text,
  $tableContactColGender text,
  $tableContactColImage text,
  $tableContactColFavorite integer
  )''';



  static Future<Database> open() async {
    final root = await getDatabasesPath();
    final dbPath = join(root, 'contact.db');
    return openDatabase(dbPath, version: 1, onCreate: (db, version){
      db.execute(_cereateTableContact);
    });
  }
  static Future<int> insertContact(ContactModel contactModel) async {
    final db = await open();
    return db.insert(tableContact, contactModel.toMap());
  }

  static Future<List<ContactModel>> getAllContent() async {
    final db = await open();
    final List<Map<String, dynamic>> mapList = await db.query(tableContact);
    return List.generate(mapList.length, (index) => ContactModel.fromMap(mapList[index]));
  }



  static Future<ContactModel> getContactById(int id) async{
    final db = await open();
    final mapList = await db.query(tableContact, where: '$tableContactColId = ?', whereArgs: [id]);

    return ContactModel.fromMap(mapList.first);
  }

  static Future<int> updateFavorite() async {

  }


}






















