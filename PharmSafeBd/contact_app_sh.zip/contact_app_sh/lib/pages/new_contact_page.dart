import 'dart:io';
import 'package:contact_app_sh/db/sqflite_helper.dart';
import 'package:contact_app_sh/models/contact_model.dart';
import 'package:contact_app_sh/pages/contact_list_page.dart';
import 'package:contact_app_sh/provider/contact_provider.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class NewContactPage extends StatefulWidget {
  static const String routeName = '/new_contact_page';

  @override
  State<NewContactPage> createState() => _NewContactPageState();
}

class _NewContactPageState extends State<NewContactPage> {

  String? _dateOfBirth;
  String? _genderGroupValue;
  String? _imagePath;
  ImageSource _imageSource = ImageSource.camera;

  final nameController = TextEditingController();
  final numberController = TextEditingController();
  final emailController = TextEditingController();
  final addressController = TextEditingController();

  final formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    nameController.dispose();
    numberController.dispose();
    emailController.dispose();
    addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('New Contact page'),
        actions: [
          IconButton(onPressed: _saveContactInfo, icon: Icon(Icons.save))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Form(
          key: formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field must not be empty';
                  }
                  if (value.length > 20) {
                    return 'Name must be in 20 charecter';
                  } else {
                    return null;
                  }
                },
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: numberController,
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  prefixIcon: Icon(Icons.phone),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field must not be empty';
                  }
                  if (value.length > 11) {
                    return 'Phone number must be in 11 charecter';
                  } else {
                    return null;
                  }
                },
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              TextFormField(
                controller: addressController,
                decoration: InputDecoration(
                  labelText: 'Address',
                  prefixIcon: Icon(Icons.location_city),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Card(
                elevation: 10,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(onPressed: _selectDate, child: Text('select date of birth')),
                    Text(_dateOfBirth == null ? 'No date chosen' : _dateOfBirth!)

                  ],
                ),
              ),
              SizedBox(height: 15,),
              Card(
                elevation: 10,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Select Gender'),
                    Radio<String>(
                        value: 'Male',
                        groupValue: _genderGroupValue,
                        onChanged: (value){
                          setState(() {
                            _genderGroupValue = value;
                          });
                        }),
                    Text('Male'),


                    Radio<String>(
                        value: 'Female',
                        groupValue: _genderGroupValue,
                        onChanged: (value){
                          setState(() {
                            _genderGroupValue = value;
                          });
                        }),
                    Text('Female'),

                  ],
                ),
              ),
              Card(
                elevation: 5,
                child: _imagePath == null? Image.asset('images/image.jpg', height: 100, width: 100, fit: BoxFit.contain,) : Image.file(File(_imagePath!), height: 100, width: 100, fit: BoxFit.contain,),



              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(onPressed: (){
                    _imageSource = ImageSource.camera;
                    _getImage();
                  }, child: Text('Camera')),
                  SizedBox(width: 10,),
                  ElevatedButton(onPressed: (){
                    _imageSource = ImageSource.gallery;
                    _getImage();
                  }, child: Text('Galary')),
                ],
              )

            ],
          ),
        ),
      ),
    );
  }

  void _saveContactInfo() async{
    if (formKey.currentState!.validate()) {
      final contact = ContactModel(
        name: nameController.text,
        number: numberController.text,
        email: emailController.text,
        address: addressController.text,
        dataOfBirth: _dateOfBirth,
        gender: _genderGroupValue,
        image: _imagePath,
      );
      print(contact.toString());
      final status = await Provider.of<ContactProvider>(context, listen: false).addNewContact(contact);
      if(status){
        Navigator.pop(context);
      }
    }
  }

  void _selectDate() async {
    final selectedDate = await showDatePicker(context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1950),
        lastDate: DateTime(2050));

    if(selectedDate != null){
      setState(() {
        _dateOfBirth = DateFormat('dd/MM/yyyy').format(selectedDate);
      });
    }
  }

  void _getImage() async {

    final selectedImage = await  ImagePicker().pickImage(source: _imageSource);
    if(selectedImage != null){
      setState(() {
        _imagePath = selectedImage.path;
      });
    }
  }
}
