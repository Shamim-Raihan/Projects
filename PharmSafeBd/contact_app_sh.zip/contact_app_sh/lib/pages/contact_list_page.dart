import 'package:contact_app_sh/db/sqflite_helper.dart';
import 'package:contact_app_sh/models/contact_model.dart';
import 'package:contact_app_sh/pages/contact_details.dart';
import 'package:contact_app_sh/pages/new_contact_page.dart';
import 'package:contact_app_sh/provider/contact_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ContactListPage extends StatefulWidget {
  static const String routeName = '/';

  @override
  State<ContactListPage> createState() => _ContactListPageState();
}
class _ContactListPageState extends State<ContactListPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contact list'),
      ),
      body: Consumer<ContactProvider>(
        builder: (context, provider, _)=>ListView.builder(
          itemCount: provider.contactList.length,
          itemBuilder: (context, index){
            final contact = provider.contactList[index];
            return ListTile(
              onTap: ()=> Navigator.pushNamed(context, ContactDetails.routeName, arguments: contact.id),
              title: Text(contact.name),
              subtitle: Text(contact.number),
              trailing: IconButton(
                icon: Icon(contact.favorite ? Icons.favorite : Icons.favorite_border),
                onPressed: (){

                },
              ),
            );
          },
        ),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, NewContactPage.routeName);
        },
        child: Icon(Icons.add),
        tooltip: 'Add new contact',
      ),
    );
  }
}
