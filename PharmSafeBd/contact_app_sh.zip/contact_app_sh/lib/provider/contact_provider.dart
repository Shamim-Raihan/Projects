import 'package:contact_app_sh/db/sqflite_helper.dart';
import 'package:flutter/cupertino.dart';

import '../models/contact_model.dart';

class ContactProvider extends ChangeNotifier {
  List<ContactModel> contactList = [];

  getAllContact(){
    DBHelper.getAllContent().then((value){
      contactList = value;
    });
  }

  Future<ContactModel> getContactById(int id) => DBHelper.getContactById(id);


  Future<bool> addNewContact(ContactModel contactModel) async{
    final rowId = await DBHelper.insertContact(contactModel);
    if(rowId > 0){
      contactModel.id = rowId;
      contactList.add(contactModel);
      notifyListeners();
      return true;
    }
    else {
      return false;
    }
  }




}